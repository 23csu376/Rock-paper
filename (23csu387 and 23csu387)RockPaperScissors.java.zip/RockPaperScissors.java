import java.util.Random;
import java.util.Scanner;

public class RockPaperScissors {
    // Enum for the possible moves
    enum Move {
        ROCK, PAPER, SCISSORS;
    }

    public static void main(String[] args) {
        // Create scanner object for user input
        Scanner scanner = new Scanner(System.in);
        
        // Print game instructions
        System.out.println("Welcome to Rock, Paper, Scissors Game!");
        System.out.println("Enter your move: (Rock, Paper, Scissors)");

        // Get user input and convert it to uppercase for consistency
        String userInput = scanner.nextLine().toUpperCase();
        
        // Check if the user input is valid
        if (!isValidMove(userInput)) {
            System.out.println("Invalid move! Please enter Rock, Paper, or Scissors.");
            return; // Exit the game if invalid input
        }
        
        // Convert user input to Move enum
        Move userMove = Move.valueOf(userInput);
        
        // Get computer's move (randomly)
        Move computerMove = getComputerMove();

        // Display both moves
        System.out.println("Your move: " + userMove);
        System.out.println("Computer's move: " + computerMove);

        // Determine the winner
        String result = determineWinner(userMove, computerMove);

        // Print the result
        System.out.println(result);

        // Close scanner
        scanner.close();
    }

    // Check if the input is a valid move
    private static boolean isValidMove(String move) {
        try {
            Move.valueOf(move); // Try converting input to Move enum
            return true; // Valid input
        } catch (IllegalArgumentException e) {
            return false; // Invalid input
        }
    }

    // Get the computer's move randomly
    private static Move getComputerMove() {
        Random random = new Random();
        return Move.values()[random.nextInt(Move.values().length)];
    }

    // Determine the winner of the game
    private static String determineWinner(Move userMove, Move computerMove) {
        if (userMove == computerMove) {
            return "It's a draw!";
        }

        switch (userMove) {
            case ROCK:
                return (computerMove == Move.SCISSORS) ? "You win!" : "You lose!";
            case PAPER:
                return (computerMove == Move.ROCK) ? "You win!" : "You lose!";
            case SCISSORS:
                return (computerMove == Move.PAPER) ? "You win!" : "You lose!";
            default:
                return "Unexpected result.";
        }
    }
}